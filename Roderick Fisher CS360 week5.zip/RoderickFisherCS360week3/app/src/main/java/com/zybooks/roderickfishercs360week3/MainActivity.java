package com.zybooks.roderickfishercs360week3;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements TextWatcher {

    EditText nameEntered;
    TextView textGreeting;
    Button sayHelloButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //get the name from the EditText element
        nameEntered = findViewById(R.id.nameText);
        nameEntered.addTextChangedListener(this);

        //clear the default text when the edittext takes focus
        nameEntered.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean hasFocus) {
                if(hasFocus){
                    nameEntered.getText().clear();
                }
                else{
                    nameEntered.setText("Enter your name:");
                }
            }
        });

        //create the textView
        textGreeting = findViewById(R.id.textGreeting);

        //create the button
        sayHelloButton = findViewById(R.id.buttonSayHello);
    }
    public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {}

    public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
        //check for the string length
        //if length is >0 char then enable button
        sayHelloButton.setEnabled(charSequence.length() > 0);
    }

    public void afterTextChanged(Editable s){}

    public void SayHello(View view){
        //check for the null/empty
        if(nameEntered.getText().toString().matches("") ||
                nameEntered.getText().toString().matches(" ")){
            textGreeting.setText("Enter Name first: ");
        }
        else{
            textGreeting.setText("Hello, " + nameEntered.getText());
        }
    }
}